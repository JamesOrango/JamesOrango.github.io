---
layout: layouts/base.njk
title: Exemplo de Nota
date: 2025-11-18
---

## Resumo

Esta é uma nota de exemplo. Escreva suas ideias em Markdown aqui.

### Tarefas

- [ ] Estudar algoritmo X
- [x] Publicar site

```python
print("Hello, notes!")
```
