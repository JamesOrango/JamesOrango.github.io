# Personal Notes Site

Gerado com Eleventy. Para rodar localmente:

```
npm install
npm run start
```

Build:

```
npm run build
```
